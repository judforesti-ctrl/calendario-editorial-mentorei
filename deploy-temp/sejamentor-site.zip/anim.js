/* Movimento da página: blocos que surgem ao rolar, números que contam e marca-texto que se desenha. */
(function () {
  var reduz = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduz || !('IntersectionObserver' in window)) return;
  var raiz = document.documentElement;
  raiz.classList.add('js');

  var alvos = document.querySelectorAll(
    'main section:not(.hero) h2, .stats > div, .pain-text, .questions .intro > p, .questions details, ' +
    '.cmp-wrap, .cmp-note, .fit-card, .combo, .section-lead, .steps article, .stuck, .pt-head > p, ' +
    '.collage-note, .call-photo, .routine > div, .about-grid > *, .founders-row, .network, ' +
    '.price-card, .faq details, .cta-row, .journey .button, .enroll-intro > p'
  );
  alvos.forEach(function (el) {
    el.classList.add('rv');
    var i = Array.prototype.indexOf.call(el.parentNode.children, el);
    el.style.transitionDelay = Math.min(i, 5) * 70 + 'ms';
  });

  function contar(el) {
    var m = el.textContent.match(/^(\D*)([\d.]+)(.*)$/);
    if (!m) return;
    var fim = parseInt(m[2].replace(/\./g, ''), 10), t0 = null, dur = 1300;
    function passo(t) {
      if (!t0) t0 = t;
      var p = Math.min((t - t0) / dur, 1), e = 1 - Math.pow(1 - p, 3);
      el.textContent = m[1] + Math.round(fim * e).toLocaleString('pt-BR') + m[3];
      if (p < 1) requestAnimationFrame(passo); else el.textContent = m[1] + m[2] + m[3];
    }
    requestAnimationFrame(passo);
  }

  var obs = new IntersectionObserver(function (itens) {
    itens.forEach(function (it) {
      if (!it.isIntersecting) return;
      var el = it.target;
      el.classList.add('in');
      if (el.matches('.stats > div')) { var s = el.querySelector('strong'); if (s) contar(s); }
      obs.unobserve(el);
    });
  }, { threshold: 0.15, rootMargin: '0px 0px -6% 0px' });

  alvos.forEach(function (el) { obs.observe(el); });
  document.querySelectorAll('mark.hl').forEach(function (el) { obs.observe(el); });
})();
