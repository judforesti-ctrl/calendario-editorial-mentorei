/* Rastreio da página. Preencha os códigos abaixo e publique de novo.
   Enquanto estiverem vazios, nenhum cookie é criado e nenhum aviso aparece. */
var PIXEL_META = '';            // exemplo: '123456789012345'
var TAG_GOOGLE = '';            // exemplo: 'AW-123456789' ou 'G-XXXXXXXXXX'
var CONVERSAO_FORMULARIO = '';  // exemplo: 'AW-123456789/AbC-D_efGhIj'
var CONVERSAO_WHATSAPP = '';    // exemplo: 'AW-123456789/XyZ-1_234abCd'

(function () {
  var ehObrigado = document.documentElement.getAttribute('data-pagina') === 'obrigado';
  var CHAVE_CONSENTIMENTO = 'mentorei_consentimento';
  var CHAVE_ORIGEM = 'mentorei_origem';

  /* ---------- de onde veio a visita ---------- */

  function guardaOrigem() {
    try {
      var p = new URLSearchParams(location.search), d = {};
      ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'gclid', 'fbclid']
        .forEach(function (k) { if (p.get(k)) d[k] = p.get(k); });
      if (Object.keys(d).length) {
        d.ref = document.referrer || '';
        sessionStorage.setItem(CHAVE_ORIGEM, JSON.stringify(d));
      }
    } catch (e) {}
  }

  function leOrigem() {
    try { return JSON.parse(sessionStorage.getItem(CHAVE_ORIGEM) || '{}'); } catch (e) { return {}; }
  }

  function rotulo() {
    var o = leOrigem();
    if (o.gclid || o.utm_source === 'google') return 'google';
    if (o.fbclid || ['facebook', 'instagram', 'meta', 'ig', 'fb'].indexOf(o.utm_source) > -1) return 'meta';
    if (o.utm_source) return String(o.utm_source).slice(0, 30);
    if (document.referrer && document.referrer.indexOf(location.host) === -1) return 'indicacao';
    return 'direto';
  }

  function preencheFormulario() {
    var f = document.querySelector('form[name="conversa"]');
    if (!f) return;
    var o = leOrigem();
    var set = function (n, v) { var c = f.querySelector('[name="' + n + '"]'); if (c) c.value = v || ''; };
    set('origem', rotulo());
    set('campanha', o.utm_campaign);
    set('termo', o.utm_term);
  }

  function marcaWhatsApp() {
    var tag = rotulo();
    [].forEach.call(document.querySelectorAll('a[href*="wa.me"]'), function (a) {
      if (a.href.indexOf('ref%3A') === -1) a.href = a.href + encodeURIComponent(' (ref: ' + tag + ')');
      a.addEventListener('click', function () {
        if (window.gtag) {
          gtag('event', 'clique_whatsapp', { origem: tag });
          if (CONVERSAO_WHATSAPP) gtag('event', 'conversion', { send_to: CONVERSAO_WHATSAPP });
        }
        if (window.fbq) fbq('track', 'Contact');
      });
    });
  }

  /* ---------- pixels, só depois do aceite ---------- */

  function carregaPixels() {
    if (PIXEL_META) {
      !function (f, b, e, v, n, t, s) {
        if (f.fbq) return; n = f.fbq = function () { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments) };
        if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = '2.0'; n.queue = [];
        t = b.createElement(e); t.async = !0; t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s)
      }(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', PIXEL_META);
      fbq('track', 'PageView');
      if (ehObrigado) fbq('track', 'Lead');
    }
    if (TAG_GOOGLE) {
      var g = document.createElement('script');
      g.async = true;
      g.src = 'https://www.googletagmanager.com/gtag/js?id=' + TAG_GOOGLE;
      document.head.appendChild(g);
      window.dataLayer = window.dataLayer || [];
      window.gtag = function () { dataLayer.push(arguments); };
      gtag('js', new Date());
      gtag('config', TAG_GOOGLE);
      if (ehObrigado && CONVERSAO_FORMULARIO) {
        gtag('event', 'conversion', { send_to: CONVERSAO_FORMULARIO, origem: rotulo() });
      }
    }
  }

  /* ---------- aviso de cookies ---------- */

  function aviso() {
    if (!PIXEL_META && !TAG_GOOGLE) return;
    var d = document.createElement('div');
    d.className = 'cookie-aviso';
    d.setAttribute('role', 'dialog');
    d.setAttribute('aria-label', 'Aviso de cookies');
    d.innerHTML = '<p>A gente usa cookies para entender de onde vêm as visitas e melhorar o site. ' +
      'Veja a <a href="/politica-de-privacidade">Política de Privacidade</a>.</p>' +
      '<div class="cookie-botoes"><button type="button" data-aceita="sim">Aceitar</button>' +
      '<button type="button" data-aceita="nao">Recusar</button></div>';
    d.addEventListener('click', function (ev) {
      var b = ev.target.closest('[data-aceita]');
      if (!b) return;
      try { localStorage.setItem(CHAVE_CONSENTIMENTO, b.getAttribute('data-aceita')); } catch (e) {}
      d.remove();
      if (b.getAttribute('data-aceita') === 'sim') carregaPixels();
    });
    document.body.appendChild(d);
  }

  /* ---------- início ---------- */

  guardaOrigem();
  preencheFormulario();
  marcaWhatsApp();

  var escolha = null;
  try { escolha = localStorage.getItem(CHAVE_CONSENTIMENTO); } catch (e) {}
  if (escolha === 'sim') carregaPixels();
  else if (escolha !== 'nao') aviso();
})();
